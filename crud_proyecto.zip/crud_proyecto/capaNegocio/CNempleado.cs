﻿using capaEntidad;
using capaDatos;
using System.Data;

namespace capaNegocio
{
    public class CNempleado
    {
        CDEmpleados CDEmpleados = new CDEmpleados();
        public bool ValidarDatos(CEempleados empleado)
        {
            bool resultado = true;

            if (empleado.Nombre == string.Empty)
            {
                resultado = false;
                MessageBox.Show("El nombre es obligatorio");
            }
            if (empleado.Apellido == string.Empty)
            {
                resultado = false;
                MessageBox.Show("El apellido es obligatorio");
            }
            if (empleado.Direccion == string.Empty)
            {
                resultado = false;
                MessageBox.Show("La direccion es obligatorio");
            }
            if (empleado.Telefono == string.Empty)
            {
                resultado = false;
                MessageBox.Show("El telefono es obligatorio");
            }
            if (empleado.Foto == null)
            {
                resultado = false;
                MessageBox.Show("La foto es obligatorio");
            }
            return resultado;
        }
        public void PruebaMysql()
        {
            CDEmpleados.PruebaConexion();
        }
        public void CrearCliente(CEempleados cE)
        {
            CDEmpleados.Crear(cE);
        }
        public void EditarCliente(CEempleados cE)
        {
            CDEmpleados.Editar(cE);
        }
        public void EliminarCliente(CEempleados cE)
        {
            CDEmpleados.Eliminar(cE);
        }
        public DataSet ObtenerDatos()
        {
            return CDEmpleados.Listar();
        }
        
    }
        
}
