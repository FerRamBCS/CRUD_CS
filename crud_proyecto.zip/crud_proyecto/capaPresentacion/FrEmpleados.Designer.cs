﻿namespace capaPresentacion
{
    partial class FrEmpleados
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Lbl_id = new Label();
            Lbl_nombre = new Label();
            Lbl_direccion = new Label();
            Lbl_apellidos = new Label();
            Lbl_imagen = new Label();
            Lbl_telefono = new Label();
            Txt_nombre = new TextBox();
            Txt_apellido = new TextBox();
            Txt_id = new NumericUpDown();
            Txt_direccion = new TextBox();
            Txt_telefono = new TextBox();
            Link_seleccionar = new LinkLabel();
            Picb_foto = new PictureBox();
            Ofd_foto = new OpenFileDialog();
            Btn_guardar = new Button();
            Btn_nuevo = new Button();
            Btn_eliminar = new Button();
            Dgv_tabla = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)Txt_id).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Picb_foto).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Dgv_tabla).BeginInit();
            SuspendLayout();
            // 
            // Lbl_id
            // 
            Lbl_id.AutoSize = true;
            Lbl_id.Location = new Point(26, 32);
            Lbl_id.Name = "Lbl_id";
            Lbl_id.Size = new Size(24, 20);
            Lbl_id.TabIndex = 0;
            Lbl_id.Text = "ID";
            // 
            // Lbl_nombre
            // 
            Lbl_nombre.AutoSize = true;
            Lbl_nombre.Location = new Point(26, 88);
            Lbl_nombre.Name = "Lbl_nombre";
            Lbl_nombre.Size = new Size(64, 20);
            Lbl_nombre.TabIndex = 1;
            Lbl_nombre.Text = "Nombre";
            // 
            // Lbl_direccion
            // 
            Lbl_direccion.AutoSize = true;
            Lbl_direccion.Location = new Point(26, 192);
            Lbl_direccion.Name = "Lbl_direccion";
            Lbl_direccion.Size = new Size(72, 20);
            Lbl_direccion.TabIndex = 3;
            Lbl_direccion.Text = "Dirección";
            // 
            // Lbl_apellidos
            // 
            Lbl_apellidos.AutoSize = true;
            Lbl_apellidos.Location = new Point(26, 136);
            Lbl_apellidos.Name = "Lbl_apellidos";
            Lbl_apellidos.Size = new Size(72, 20);
            Lbl_apellidos.TabIndex = 2;
            Lbl_apellidos.Text = "Apellidos";
            // 
            // Lbl_imagen
            // 
            Lbl_imagen.AutoSize = true;
            Lbl_imagen.Location = new Point(26, 331);
            Lbl_imagen.Name = "Lbl_imagen";
            Lbl_imagen.Size = new Size(156, 20);
            Lbl_imagen.TabIndex = 5;
            Lbl_imagen.Text = "Imagen del empleado";
            // 
            // Lbl_telefono
            // 
            Lbl_telefono.AutoSize = true;
            Lbl_telefono.Location = new Point(26, 243);
            Lbl_telefono.Name = "Lbl_telefono";
            Lbl_telefono.Size = new Size(67, 20);
            Lbl_telefono.TabIndex = 4;
            Lbl_telefono.Text = "Teléfono";
            // 
            // Txt_nombre
            // 
            Txt_nombre.Location = new Point(192, 80);
            Txt_nombre.Margin = new Padding(3, 4, 3, 4);
            Txt_nombre.Name = "Txt_nombre";
            Txt_nombre.Size = new Size(114, 27);
            Txt_nombre.TabIndex = 7;
            // 
            // Txt_apellido
            // 
            Txt_apellido.Location = new Point(192, 128);
            Txt_apellido.Margin = new Padding(3, 4, 3, 4);
            Txt_apellido.Name = "Txt_apellido";
            Txt_apellido.Size = new Size(114, 27);
            Txt_apellido.TabIndex = 8;
            // 
            // Txt_id
            // 
            Txt_id.Enabled = false;
            Txt_id.Location = new Point(192, 24);
            Txt_id.Margin = new Padding(3, 4, 3, 4);
            Txt_id.Name = "Txt_id";
            Txt_id.Size = new Size(137, 27);
            Txt_id.TabIndex = 9;
            // 
            // Txt_direccion
            // 
            Txt_direccion.Location = new Point(192, 184);
            Txt_direccion.Margin = new Padding(3, 4, 3, 4);
            Txt_direccion.Name = "Txt_direccion";
            Txt_direccion.Size = new Size(114, 27);
            Txt_direccion.TabIndex = 10;
            // 
            // Txt_telefono
            // 
            Txt_telefono.Location = new Point(192, 235);
            Txt_telefono.Margin = new Padding(3, 4, 3, 4);
            Txt_telefono.Name = "Txt_telefono";
            Txt_telefono.Size = new Size(114, 27);
            Txt_telefono.TabIndex = 11;
            // 
            // Link_seleccionar
            // 
            Link_seleccionar.AutoSize = true;
            Link_seleccionar.Location = new Point(26, 365);
            Link_seleccionar.Name = "Link_seleccionar";
            Link_seleccionar.Size = new Size(85, 20);
            Link_seleccionar.TabIndex = 12;
            Link_seleccionar.TabStop = true;
            Link_seleccionar.Text = "Saleccionar";
            Link_seleccionar.LinkClicked += Link_seleccionar_LinkClicked;
            // 
            // Picb_foto
            // 
            Picb_foto.BackColor = SystemColors.ActiveBorder;
            Picb_foto.Location = new Point(192, 273);
            Picb_foto.Margin = new Padding(3, 4, 3, 4);
            Picb_foto.Name = "Picb_foto";
            Picb_foto.Size = new Size(175, 177);
            Picb_foto.SizeMode = PictureBoxSizeMode.StretchImage;
            Picb_foto.TabIndex = 13;
            Picb_foto.TabStop = false;
            // 
            // Ofd_foto
            // 
            Ofd_foto.FileName = "openFileDialog1";
            // 
            // Btn_guardar
            // 
            Btn_guardar.Location = new Point(159, 511);
            Btn_guardar.Margin = new Padding(3, 4, 3, 4);
            Btn_guardar.Name = "Btn_guardar";
            Btn_guardar.Size = new Size(86, 31);
            Btn_guardar.TabIndex = 14;
            Btn_guardar.Text = "Guardar";
            Btn_guardar.UseVisualStyleBackColor = true;
            Btn_guardar.Click += Btn_guardar_Click;
            // 
            // Btn_nuevo
            // 
            Btn_nuevo.Location = new Point(26, 511);
            Btn_nuevo.Margin = new Padding(3, 4, 3, 4);
            Btn_nuevo.Name = "Btn_nuevo";
            Btn_nuevo.Size = new Size(86, 31);
            Btn_nuevo.TabIndex = 15;
            Btn_nuevo.Text = "Nuevo";
            Btn_nuevo.UseVisualStyleBackColor = true;
            Btn_nuevo.Click += Btn_nuevo_Click;
            // 
            // Btn_eliminar
            // 
            Btn_eliminar.Location = new Point(298, 511);
            Btn_eliminar.Margin = new Padding(3, 4, 3, 4);
            Btn_eliminar.Name = "Btn_eliminar";
            Btn_eliminar.Size = new Size(86, 31);
            Btn_eliminar.TabIndex = 16;
            Btn_eliminar.Text = "Eliminar";
            Btn_eliminar.UseVisualStyleBackColor = true;
            Btn_eliminar.Click += Btn_eliminar_Click;
            // 
            // Dgv_tabla
            // 
            Dgv_tabla.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Dgv_tabla.Location = new Point(488, 24);
            Dgv_tabla.Name = "Dgv_tabla";
            Dgv_tabla.RowHeadersWidth = 51;
            Dgv_tabla.RowTemplate.Height = 29;
            Dgv_tabla.Size = new Size(804, 426);
            Dgv_tabla.TabIndex = 17;
            Dgv_tabla.CellDoubleClick += Dgv_tabla_CellDoubleClick;
            // 
            // FrEmpleados
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1385, 572);
            Controls.Add(Dgv_tabla);
            Controls.Add(Btn_eliminar);
            Controls.Add(Btn_nuevo);
            Controls.Add(Btn_guardar);
            Controls.Add(Picb_foto);
            Controls.Add(Link_seleccionar);
            Controls.Add(Txt_telefono);
            Controls.Add(Txt_direccion);
            Controls.Add(Txt_id);
            Controls.Add(Txt_apellido);
            Controls.Add(Txt_nombre);
            Controls.Add(Lbl_imagen);
            Controls.Add(Lbl_telefono);
            Controls.Add(Lbl_direccion);
            Controls.Add(Lbl_apellidos);
            Controls.Add(Lbl_nombre);
            Controls.Add(Lbl_id);
            Name = "FrEmpleados";
            Text = "Empleados";
            Load += FrEmpleados_Load;
            ((System.ComponentModel.ISupportInitialize)Txt_id).EndInit();
            ((System.ComponentModel.ISupportInitialize)Picb_foto).EndInit();
            ((System.ComponentModel.ISupportInitialize)Dgv_tabla).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Lbl_id;
        private Label Lbl_nombre;
        private Label Lbl_direccion;
        private Label Lbl_apellidos;
        private Label Lbl_imagen;
        private Label Lbl_telefono;
        private TextBox Txt_nombre;
        private TextBox Txt_apellido;
        private NumericUpDown Txt_id;
        private TextBox Txt_direccion;
        private TextBox Txt_telefono;
        private LinkLabel Link_seleccionar;
        private PictureBox Picb_foto;
        private OpenFileDialog Ofd_foto;
        private Button Btn_guardar;
        private Button Btn_nuevo;
        private Button Btn_eliminar;
        private DataGridView Dgv_tabla;
    }
}