using capaEntidad;
using capaNegocio;
namespace capaPresentacion
{
    public partial class FrEmpleados : Form
    {
        CNempleado CNempleado = new CNempleado();
        public FrEmpleados()
        {
            InitializeComponent();
        }
        private void Btn_nuevo_Click(object sender, EventArgs e)
        {
            LimpiarForm();
        }
        private void LimpiarForm()
        {
            Txt_id.ResetText();
            Txt_nombre.Text = string.Empty;
            Txt_apellido.Text = string.Empty;
            Txt_direccion.Text = string.Empty;
            Txt_telefono.Text = string.Empty;
            Picb_foto.Image = null;
        }
        private void Link_seleccionar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Ofd_foto.FileName = string.Empty;

            if (Ofd_foto.ShowDialog() == DialogResult.OK)
            {
                Picb_foto.Load(Ofd_foto.FileName);
            }
            Ofd_foto.FileName = string.Empty;
        }

        private void Btn_guardar_Click(object sender, EventArgs e)
        {
            bool resultado;

            CEempleados cEempleados = new CEempleados();
            cEempleados.Id = (int)Txt_id.Value;
            cEempleados.Nombre = Txt_nombre.Text;
            cEempleados.Apellido = Txt_apellido.Text;
            cEempleados.Direccion = Txt_direccion.Text;
            cEempleados.Telefono = Txt_telefono.Text;
            cEempleados.Foto = Picb_foto.ImageLocation;
            resultado = CNempleado.ValidarDatos(cEempleados);
            if (resultado == false)
            {
                return;
            }
            if (cEempleados.Id == 0) {
                CNempleado.CrearCliente(cEempleados);
            }
            else
            {
                CNempleado.EditarCliente(cEempleados);
            }
            CargarDatos();
            LimpiarForm();
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (Txt_id.Value == 0)
            {
                return;
            }
            if (MessageBox.Show("!ALERTA�, Estas a punto de eliminar un campo, �Deseas continuar?", "Titulo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                CEempleados cE = new CEempleados();
                cE.Id = (int)Txt_id.Value;
                CNempleado.EliminarCliente(cE);
                CargarDatos();
                LimpiarForm();
            }

        }
        private void FrEmpleados_Load(object sender, EventArgs e)
        {
            CargarDatos();
        }
        private void CargarDatos()
        {
            Dgv_tabla.DataSource = CNempleado.ObtenerDatos().Tables["tbl"];
        }

        private void Dgv_tabla_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            Txt_id.Value = (int)Dgv_tabla.CurrentRow.Cells["id"].Value;
            Txt_nombre.Text = Dgv_tabla.CurrentRow.Cells["nombre"].Value.ToString();
            Txt_apellido.Text = Dgv_tabla.CurrentRow.Cells["apellidos"].Value.ToString();
            Txt_direccion.Text = Dgv_tabla.CurrentRow.Cells["direccion"].Value.ToString();
            Txt_telefono.Text = Dgv_tabla.CurrentRow.Cells["telefono"].Value.ToString();
            Picb_foto.Load(Dgv_tabla.CurrentRow.Cells["Foto"].Value.ToString());

        }
    }
}