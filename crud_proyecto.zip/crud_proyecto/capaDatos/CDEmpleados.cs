﻿using MySql.Data.MySqlClient;
using capaEntidad;
using System.Data;

namespace capaDatos
{
    public class CDEmpleados
    {
        string CadenaConexion = "Server=localhost;User=root;Password=;Port=3306;database=crud_cs;";


        public void PruebaConexion()
        {
            MySqlConnection mySqlConnection = new MySqlConnection(CadenaConexion);

            try
            {
                mySqlConnection.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de conexion"+ex.Message);
                return;
            }
            mySqlConnection.Close();
            MessageBox.Show("Conectado");

        }
        public void Crear(CEempleados cE)
        {
            MySqlConnection mySqlConnection = new MySqlConnection(CadenaConexion);
            mySqlConnection.Open();
            string query = "INSERT INTO `empleados`(`nombre`, `apellidos`, `direccion`, `telefono`, `Foto`) VALUES ('" + cE.Nombre+"','"+cE.Apellido+"','"+cE.Direccion+"','"+cE.Telefono+"','"+MySql.Data.MySqlClient.MySqlHelper.EscapeString(cE.Foto)+"');";

            MySqlCommand mySqlCommand = new MySqlCommand(query, mySqlConnection);
            mySqlCommand.ExecuteNonQuery();
            mySqlConnection.Close();
            MessageBox.Show("Registro realizado con exito"); 
        }
        public void Editar(CEempleados cE)
        {
            MySqlConnection mySqlConnection = new MySqlConnection(CadenaConexion);
            mySqlConnection.Open();
            string query = "UPDATE `empleados` SET `nombre`='" + cE.Nombre + "'," +
                           "`apellidos`='" + cE.Apellido + "'," +
                           "`direccion`='" + cE.Direccion + "'," +
                           "`telefono`='" + cE.Telefono + "'," +
                           "`Foto`='" + MySql.Data.MySqlClient.MySqlHelper.EscapeString(cE.Foto) + "'" +
                           " WHERE `id` =" + cE.Id + ";";
            MySqlCommand mySqlCommand = new MySqlCommand(query, mySqlConnection);
            mySqlCommand.ExecuteNonQuery();
            mySqlConnection.Close();
            MessageBox.Show("Registro actualizado con exito");
        }
        public void Eliminar(CEempleados cE)
        {
            MySqlConnection mySqlConnection = new MySqlConnection(CadenaConexion);
            mySqlConnection.Open();
            string query = "DELETE FROM `empleados` WHERE `id` = " + cE.Id + ";";
            MySqlCommand mySqlCommand = new MySqlCommand(query, mySqlConnection);
            mySqlCommand.ExecuteNonQuery();
            mySqlConnection.Close();
            MessageBox.Show("Registro Eliminado con exito");
        }
        public DataSet Listar()
        {
            MySqlConnection mySqlConnection = new MySqlConnection(CadenaConexion);
            mySqlConnection.Open();
            string query = "SELECT * FROM `empleados`";
            MySqlDataAdapter Adaptador;
            DataSet dataSet = new DataSet();

            Adaptador = new MySqlDataAdapter(query, mySqlConnection);
            Adaptador.Fill(dataSet, "tbl");

            return dataSet;
        }
    }
}